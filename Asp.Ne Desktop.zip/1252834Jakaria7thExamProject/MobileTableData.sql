use [OnlineShop]
go
insert into Mobile values('Nokia','2','4 GB','16 MP',16000,2016,'~/Upload/71X3pFLVixL._AC_SL1500_.jpg'),
						('Mi','A1','4 GB','16 MP',20000,2016,'~/Upload/Mi-A1.PNG'),
						('Mi','A2','4 GB','16 MP',25000,2017,'~/Upload/Mi-A1.PNG'),
						('Mi','A3','4 GB','16 MP',30000,2019,'~/Upload/Mi-A3.jpeg')

