﻿using _7thExamProject.Models.DA;
using _7thExamProject.Models.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadData();
            LoadData2();
        }

        private void LoadData2()
        {
            string conString = @"Data Source=.\SQLEXPRESS;initial catalog=OnlineShop;trusted_connection=True;";
            using (SqlConnection con = new SqlConnection(conString))
            {
                string sqlCmd = "select * from	[mobile]";
                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCmd, con); //ADO.NET Data Adapter//
                DataTable dt = new DataTable();
                dataAdapter.Fill(dt);

                dataGridView2.DataSource = dt;
            }
        }

        private void LoadData()
        {
            string conString = @"Data Source=.\SQLEXPRESS;initial catalog=OnlineShop;trusted_connection=True;";
            using (SqlConnection con = new SqlConnection(conString))
            {
                string sqlCmd = "select * from	[Order]";
                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCmd, con); //ADO.NET Data Adapter//
                DataTable dt = new DataTable();
                dataAdapter.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OrderDTO o = new OrderDTO();
            o.MobileID = Int32.Parse(txtMID.Text);
            o.Quantity = Int32.Parse(txtQ.Text);
            o.Address = txtAdd.Text;
            if (new OrderDA().CRUD(o, "insert") > 0)
            {
                MessageBox.Show("Save Successfully.");
                LoadData();
                clearAll();

            }
            clearAll();
        }

        private void clearAll()
        {
            
            txtMID.Text = "";
            txtQ.Text = "";
            txtAdd.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OrderDTO o = new OrderDTO();
            o.Id = Int32.Parse(lblId.Text);

            if (new OrderDA().CRUD(o, "delete") > 0)
            {
                MessageBox.Show("Deleted Successfully.");
                clearAll();
                LoadData();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OrderDTO o = new OrderDTO();
            o.Id = Int32.Parse(lblId.Text);
            o.MobileID = Int32.Parse(txtMID.Text);
            o.Quantity = Int32.Parse(txtQ.Text);
            o.Address = txtAdd.Text;

            if (new OrderDA().CRUD(o, "update") > 0)
            {
                MessageBox.Show("Updated Successfully.");
                clearAll();
                LoadData();
            }
        }

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());

            OrderDTO o = new OrderDA().GetByID(id);
            if (o != null)
            {
                lblId.Text = o.Id.ToString();
                txtMID.Text = o.MobileID.ToString();
                txtQ.Text = o.Quantity.ToString();
                txtAdd.Text = o.Address.ToString();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());

            MobileDTO o = new MobileDA().GetByID(id);
            if (o != null)
            {
                
                txtMID.Text = o.Id.ToString();
                
            }
        }
    }
}
