﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using _7thExamProject.Models.DTO;

namespace _7thExamProject.Models.DA
{
    public class OrderDA
    {
        string conString = @"Data Source=.\SQLEXPRESS;initial catalog=OnlineShop;trusted_connection=True;";
        public int CRUD(OrderDTO order, string commandtype)
        {
            int result = 0;
            string sql = "";
            if (commandtype == "insert")
            {
                sql = $"Insert into [order] values({order.MobileID},{order.Quantity},'{order.Address}')";

            }
            else if (commandtype == "update")
            {
                sql = $"Update [order] set MobileId='{order.MobileID}',Quantity='{order.Quantity}',Address='{order.Address}' where id={order.Id}";

            }
            else if (commandtype == "delete")
            {
                sql = $"Delete [order] where Id={order.Id}";

            }
            using (SqlConnection con = new SqlConnection(conString))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand(sql, con);
                result = cmd.ExecuteNonQuery();
                con.Close();
            }

            return result;
        }
        public List<OrderDTO> AllData()
        {
            List<OrderDTO> lst = new List<OrderDTO>();
            string sql = "Select * from [order] Order by ID Desc";
            using (SqlConnection con = new SqlConnection(conString))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand command = new SqlCommand(sql, con);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        OrderDTO order = new OrderDTO();
                        order.Id = Int32.Parse(reader["Id"].ToString());
                        order.MobileID = Int32.Parse(reader["MobileID"].ToString());
                        order.Quantity = Int32.Parse(reader["Quantity"].ToString());
                        order.Address = reader["Address"].ToString();
                        lst.Add(order);
                    }
                }
                reader.Close();
                con.Close();
            }
            return lst;
        }

        public OrderDTO GetByID(int id)
        {
            OrderDTO order = new OrderDTO();
            string sql = $"select * from [order] where Id={id}";
            using (SqlConnection con = new SqlConnection(conString))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlDataReader reader = new SqlCommand(sql, con).ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        order.Id = Int32.Parse(reader["Id"].ToString());
                        order.MobileID = Int32.Parse(reader["MobileId"].ToString());
                        order.Quantity = Int32.Parse(reader["Quantity"].ToString());
                        order.Address = reader["Address"].ToString();
                    }
                }
                reader.Close();
                con.Close();
            }
            return order;
        }
    }
}