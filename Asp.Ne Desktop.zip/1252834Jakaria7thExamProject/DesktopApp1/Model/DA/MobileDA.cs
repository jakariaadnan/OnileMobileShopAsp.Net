﻿using _7thExamProject.Models.DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace _7thExamProject.Models.DA
{
    public class MobileDA
    {
        string conString = @"Data Source=.\SQLEXPRESS;initial catalog=OnlineShop;trusted_connection=True;";
        public int CRUD(MobileDTO mobile, string commandtype)
        {
            int result = 0;
            string sql = "";
            if (commandtype == "insert")
            {
                sql = $"Insert into Mobile values('{mobile.MobileCompany}','{mobile.ModelName}','{mobile.RAM}','{mobile.Camera}','{mobile.Price}','{mobile.ReleaseYear}','{mobile.Photo}')";

            }
            else if (commandtype == "update")
            {
                sql = $"Update Mobile set MobileCompany='{mobile.MobileCompany}',ModelName='{mobile.ModelName}',Price='{mobile.Price}',ReleaseYear='{mobile.ReleaseYear}',Photo='{mobile.Photo}' where Id={mobile.Id}";

            }
            else if (commandtype == "delete")
            {
                sql = $"Delete Mobile where Id={mobile.Id}";

            }
            using (SqlConnection con = new SqlConnection(conString))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand(sql, con);
                result = cmd.ExecuteNonQuery();
                con.Close();
            }

            return result;
        }
        public List<MobileDTO> AllData()
        {
            List<MobileDTO> lst = new List<MobileDTO>();
            string sql = "Select * from Mobile Order by ID Desc";
            using (SqlConnection con = new SqlConnection(conString))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand command = new SqlCommand(sql, con);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        MobileDTO mobile = new MobileDTO();
                        mobile.Id = Int32.Parse(reader["Id"].ToString());
                        mobile.MobileCompany = reader["MobileCompany"].ToString();
                        mobile.ModelName = reader["ModelName"].ToString();
                        mobile.RAM = reader["RAM"].ToString();
                        mobile.Camera = reader["Camera"].ToString();
                        mobile.Price = Int32.Parse(reader["Price"].ToString());
                        mobile.ReleaseYear = Int32.Parse(reader["ReleaseYear"].ToString());
                        mobile.Photo = reader["Photo"].ToString();
                        lst.Add(mobile);
                    }
                }
                reader.Close();
                con.Close();
            }
            return lst;
        }

        public MobileDTO GetByID(int id)
        {
            MobileDTO mobile = new MobileDTO();
            string sql = $"select * from Mobile where Id={id}";
            using (SqlConnection con = new SqlConnection(conString))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlDataReader reader = new SqlCommand(sql, con).ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        mobile.Id = Int32.Parse(reader["Id"].ToString());
                        mobile.MobileCompany = reader["MobileCompany"].ToString();
                        mobile.ModelName = reader["ModelName"].ToString();
                        mobile.RAM = reader["RAM"].ToString();
                        mobile.Camera = reader["Camera"].ToString();
                        mobile.Price = Int32.Parse(reader["Price"].ToString());
                        mobile.ReleaseYear = Int32.Parse(reader["ReleaseYear"].ToString());
                        mobile.Photo = reader["Photo"].ToString();
                    }
                }
                reader.Close();
                con.Close();
            }
            return mobile;
        }
    }
}