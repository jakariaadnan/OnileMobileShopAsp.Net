using _7thExamProject.Models.DA;
using _7thExamProject.Models.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            string conString = @"Data Source=.\SQLEXPRESS;initial catalog=OnlineShop;trusted_connection=True;";
            using (SqlConnection con = new SqlConnection(conString))
            {
                string sqlCmd = "select * from	Mobile";
                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCmd, con); //ADO.NET Data Adapter//
                DataTable dt = new DataTable();
                dataAdapter.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            MobileDTO mobile = new MobileDTO();
            mobile.MobileCompany = txtMC.Text;
            mobile.ModelName = txtMN.Text;
            mobile.ReleaseYear = Int32.Parse(txtRY.Text);
            mobile.RAM = txtRAM.Text;
            mobile.Camera = txtCamera.Text;
            mobile.Price = Int32.Parse(txtPrice.Text);
            mobile.Photo = filePath;
            File.Copy(filePath, Path.Combine(@"F:\1252834Jakaria7thExamProject\DesktopApp1\image", Path.GetFileName(filePath)), true);
            if (new MobileDA().CRUD(mobile, "insert") > 0)
            {
                MessageBox.Show("Save Successfully.");
                LoadData();
                clearAll();

            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            MobileDTO m = new MobileDTO();
            m.Id = Int32.Parse(lblhidden.Text);

            if (new MobileDA().CRUD(m, "delete") > 0)
            {
                MessageBox.Show("Deleted Successfully.");
                clearAll();
                LoadData();
            }
        }

        private void clearAll()
        {
            txtMC.Text = "";
            txtMN.Text = "";
            txtRY.Text = "";
            txtRAM.Text = "";
            txtCamera.Text = "";
            txtPrice.Text = "";
        }

        
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            MobileDTO mobile = new MobileDTO();
            mobile.Id = Int32.Parse(lblhidden.Text);
            mobile.MobileCompany = txtMC.Text;
            mobile.ModelName = txtMN.Text;
            mobile.ReleaseYear = Int32.Parse(txtRY.Text);
            mobile.RAM = txtRAM.Text;
            mobile.Camera = txtCamera.Text;
            mobile.Price = Int32.Parse(txtPrice.Text);

            if (new MobileDA().CRUD(mobile, "update") > 0)
            {
                MessageBox.Show("Update Successfully.");
                clearAll();
                LoadData();
            }

        }
        string filePath = "";
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp|all files|*.*";

            if (fileDialog.ShowDialog() == DialogResult.OK)
            {


                filePath = fileDialog.FileName;
                picBox.ImageLocation = filePath;
                picBox.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());

            MobileDTO mobile = new MobileDA().GetByID(id);
            if (mobile != null)
            {
                lblhidden.Text = mobile.Id.ToString();
                txtMC.Text= mobile.MobileCompany;
                txtMN.Text= mobile.ModelName;
               txtRY.Text= mobile.ReleaseYear.ToString();
                txtRAM.Text=mobile.RAM;
                txtCamera.Text= mobile.Camera;
                txtPrice.Text= mobile.Price.ToString();
            }
        }
    }
}
