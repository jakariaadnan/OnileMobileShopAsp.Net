﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopApp1
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string conString = @"Data Source=.\SQLEXPRESS;initial catalog=OnlineShop;trusted_connection=True;";
            using (SqlConnection con = new SqlConnection(conString))
            {
                string sql = $"select count(*) from deskAuthentication where username='{txtUsername.Text}' and password='{txtPassword.Text}'";
                if (con.State != System.Data.ConnectionState.Open)
                {
                    con.Open();
                }

                SqlCommand cmd = new SqlCommand(sql, con);

                object obj = cmd.ExecuteScalar();

                if (Int32.Parse(obj.ToString()) > 0)
                {
                    this.Hide();
                    new MDIParent1().Show();
                }
                else
                {
                    MessageBox.Show("Enter Username And Password");
                }


            }
        }
    }
}
