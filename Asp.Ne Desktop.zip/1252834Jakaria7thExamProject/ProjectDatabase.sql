use master
Go
if db_id('OnlineShop') is not null
	drop database OnlineShop 
	create Database OnlineShop;
Go
Use OnlineShop
Go
Create Table Mobile
(
Id				int				identity			primary key,
MobileCompany	varchar(30),
ModelName		varchar(30),
RAM				varchar(30),
Camera			varchar(30),
Price			int,
ReleaseYear		int,
Photo			varchar(max)
)
Go
Create Table [Order]
(
Id				int				identity				primary key,
MobileId		int				References Mobile(Id)	ON DELETE CASCADE,
Quantity		int,
[Address]		varchar(max)

)
Go
Create Table DeliveryDetails
(
Id				int				identity				primary key,
OrderId			int				References [Order](Id)	ON DELETE CASCADE,
DeliveryMan		varchar(50)
);
Go
Create Table deskAuthentication
(
Id				int				identity				primary key,
UserName		varchar(50),
[Password]		varchar(50)
);
