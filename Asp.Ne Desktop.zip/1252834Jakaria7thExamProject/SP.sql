use OnlineShop
go
create proc Sp_PeoductByID
@pid varchar(50)
as
begin
SELECT d.OrderId,m.MobileCompany,m.ModelName,m.Price,o.Quantity,o.[Address],d.DeliveryMan
FROM [Mobile] m join [order] o 
on m.Id=o.MobileId
join DeliveryDetails d
on o.Id=d.OrderId 
where o.Id=@pid
end
exec Sp_PeoductByID 3